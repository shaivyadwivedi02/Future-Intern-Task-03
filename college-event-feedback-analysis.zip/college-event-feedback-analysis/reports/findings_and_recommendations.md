# Event Feedback — Findings & Recommendations

*Write for the student council / event organizers. Replace ✏️.*

## 1. Summary
✏️ 3 sentences: overall satisfaction, best and worst events, main problem.

## 2. Key Numbers
| Metric | Value |
|---|---|
| Responses analyzed | ✏️ |
| Average overall rating | ✏️ |
| % satisfied (4–5) | ✏️ |
| % negative comments | ✏️ |

## 3. Event Comparison
✏️ Rank events by rating. Which is best/worst and why (use sub-ratings and sentiment)?

## 4. What Students Said
✏️ Top liked aspects (word cloud) and top improvement themes (bar chart).

## 5. Recommendations
Use **Problem → Evidence → Action → How to measure**.
1. ✏️
2. ✏️
3. ✏️

## 6. Limitations
✏️ Simulated data, VADER misreads sarcasm, keyword themes are simple, small samples per event, only students who chose to respond.

## 7. Next Steps
✏️ e.g. trigger a shorter follow-up form, try a transformer sentiment model, track ratings across semesters.
