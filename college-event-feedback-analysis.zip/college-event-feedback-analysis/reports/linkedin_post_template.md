# LinkedIn Post Template

🎓 Just finished a **College Event Feedback Analysis** project with @Future Interns!

**The problem:** Campus events collect feedback, but rarely turn it into action.

**What I did:**
🧹 Cleaned messy Google Forms data with pandas
⭐ Analyzed 1–5 ratings across 6 events
💬 Scored comment sentiment with VADER & TextBlob (NLP)
☁️ Built charts and word clouds in Google Colab

**Key insights:**
🔹 ✏️ Insight 1 (with a number)
🔹 ✏️ Insight 2
🔹 ✏️ Insight 3

**Recommendation:** ✏️ one clear action for organizers

**Biggest learning:** ✏️ (e.g. sentiment tools can misread comments)

🔗 GitHub: ✏️ link
#DataAnalytics #NLP #Python #SentimentAnalysis #GoogleColab #FutureInterns
