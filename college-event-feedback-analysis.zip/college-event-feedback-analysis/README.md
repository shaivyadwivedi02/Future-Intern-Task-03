# 🎓 College Event Feedback Analysis (Ratings + NLP Sentiment)

> Turn Google Forms feedback from campus events into clear insights using **Python, pandas, VADER/TextBlob** — runs free in **Google Colab**, no installation needed.

![Level](https://img.shields.io/badge/level-beginner-brightgreen) ![Python](https://img.shields.io/badge/Python-pandas-3776AB) ![NLP](https://img.shields.io/badge/NLP-VADER%20%7C%20TextBlob-orange) ![Colab](https://img.shields.io/badge/Google-Colab-F9AB00)

## 🎯 Project Goal
Colleges collect feedback after tech fests, workshops and cultural nights — but is anyone using it? This project answers:
1. How satisfied are students overall, and per event?
2. Which part of an event (organization, content, venue) is weakest?
3. Are comments positive, neutral or negative?
4. What should organizers fix next time?

## 🚀 Quick Start (Google Colab — 2 minutes)
1. Download this repo (**Code → Download ZIP**) or open `notebooks/event_feedback_analysis.ipynb` on GitHub.
2. Go to [colab.research.google.com](https://colab.research.google.com) → **File → Upload notebook**.
3. Run the cells from top to bottom (**Shift + Enter**). When asked, upload `data/raw/event_feedback_raw.csv`.

*Prefer local?* `pip install -r requirements.txt`, then `jupyter notebook`.

## 📁 Repository Structure
```
college-event-feedback-analysis/
├── data/raw/          ← simulated Google Forms export (messy)
├── data/cleaned/      ← tidy reference + notebook output with sentiment
├── notebooks/         ← the main Colab/Jupyter notebook (start here!)
├── scripts/           ← script that generated the sample data
├── images/            ← charts saved by the notebook
├── docs/              ← guides: concepts, data dictionary, using your own Form
├── reports/           ← findings template + LinkedIn post template
└── requirements.txt
```

## 🗂️ Dataset
`event_feedback_raw.csv` — **615 simulated responses** across 6 events (Feb–May 2025), in the format of a Google Forms export. See the [data dictionary](docs/data_dictionary.md).

Deliberate problems to clean: 15 duplicates • very long column names • `"5 stars"` typed as a rating • an out-of-range rating (10) • blank ratings/comments • `NA`, `n/a`, `-` answers • emojis • inconsistent capitalization and spaces • mixed timestamp formats.

## 🧪 What the Notebook Does
| Step | What you learn |
|---|---|
| 1. Load | Read a CSV into pandas |
| 2. Clean | Rename columns, drop duplicates, fix ratings, handle missing text |
| 3. Ratings | Averages, distributions, sub-rating heatmap, department view |
| 4. Sentiment | VADER + TextBlob scores → Positive / Neutral / Negative |
| 5. Text insights | Word clouds and keyword-based improvement themes |
| 6. Recommendations | Turn evidence into actions |

## 📊 Sample Results (from the simulated data)
- 586 clean responses, average rating **3.76 / 5**, **63%** satisfied (4–5 stars)
- Best event: **AI & ML Workshop** (4.04) • Lowest: **Career Guidance Seminar** (3.09)
- Weakest area: **Organization**; top complaints: **time management, venue/seating, sound**
- ~16% of comments are negative

![Ratings](images/avg_rating_by_event.png)
![Sentiment](images/sentiment_by_event.png)

## ✅ Progress Checklist
- [ ] Ran the notebook end to end in Colab
- [ ] Understood every cleaning step
- [ ] Made the charts and read the heatmaps
- [ ] Explained why VADER labels can be wrong
- [ ] Wrote 3 recommendations in your own words
- [ ] Tried it on your own Google Form data
- [ ] Published to GitHub + LinkedIn post

## 📄 License
MIT
