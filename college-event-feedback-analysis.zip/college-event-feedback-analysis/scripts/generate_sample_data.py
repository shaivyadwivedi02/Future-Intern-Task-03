"""Generates a simulated Google Forms feedback export (messy) + a tidy reference version.
Run: python scripts/generate_sample_data.py   (needs pandas)"""
import random
from datetime import datetime, timedelta
import pandas as pd

random.seed(11)
events = {  # name: (type, date, base quality 1-5)
    "TechFest 2025": ("Tech Fest", datetime(2025, 2, 14), 4.2),
    "AI & ML Workshop": ("Workshop", datetime(2025, 3, 8), 4.0),
    "Cultural Night": ("Cultural", datetime(2025, 3, 29), 3.6),
    "Hackathon 24hr": ("Tech Fest", datetime(2025, 4, 12), 3.8),
    "Career Guidance Seminar": ("Seminar", datetime(2025, 5, 3), 3.1),
    "Sports Day": ("Sports", datetime(2025, 5, 24), 3.9),
}
depts = ["CSE", "ECE", "Mechanical", "Civil", "MBA", "IT"]
years = ["1st Year", "2nd Year", "3rd Year", "4th Year"]

likes_pos = ["The speakers were amazing and very knowledgeable", "Loved the hands-on activities", "Great organization and smooth coordination",
    "Really fun and engaging event", "The volunteers were helpful and friendly", "Excellent networking opportunities",
    "The content was very informative and practical", "Best event of the semester", "Great atmosphere and lots of energy",
    "Amazing performances and good vibes", "The prizes and competitions were exciting", "Well planned and interesting sessions"]
likes_neu = ["It was okay", "Some sessions were fine", "The event was average", "Nothing special but not bad", "Decent event overall"]
likes_neg = ["Nothing much to like", "Only the snacks were good", "Could not enjoy it much", "Not really what I expected"]
imp_neg = ["The sound system was terrible and we could not hear", "Too much delay, the event started 1 hour late",
    "Seating was uncomfortable and the hall was overcrowded", "Registration process was confusing and slow",
    "The food arrangement was poor and the queue was very long", "Sessions were too long and boring",
    "Poor time management", "The venue was too hot, no proper ventilation", "Need better communication and last minute changes were annoying",
    "Wifi was not working during the workshop", "Speakers were not well prepared", "Too crowded, not enough volunteers"]
imp_neu = ["Maybe start on time next time", "More variety would be nice", "Can add more breaks", "Improve the schedule a little"]
imp_pos = ["Nothing, it was perfect", "Keep it up, just add more events like this", "No complaints, great job", "Please conduct more such events"]

rows = []
for i in range(600):
    ev, (etype, edate, q) = random.choice(list(events.items()))
    overall = min(5, max(1, round(random.gauss(q, 0.9))))
    def sub(): return min(5, max(1, overall + random.choice([-1, 0, 0, 0, 1])))
    org, content, venue = sub(), sub(), sub()
    if ev == "Career Guidance Seminar": venue = min(venue, random.choice([2, 3, 3]))
    if ev == "Cultural Night": org = min(org, random.choice([2, 3, 3]))
    if overall >= 4: like, imp = random.choice(likes_pos), random.choice(imp_pos + imp_neu + imp_neg[:3])
    elif overall == 3: like, imp = random.choice(likes_neu + likes_pos[:3]), random.choice(imp_neu + imp_neg)
    else: like, imp = random.choice(likes_neg + likes_neu), random.choice(imp_neg)
    rec = "Yes" if overall >= 4 else ("Maybe" if overall == 3 else "No")
    if random.random() < .06: rec = random.choice(["Yes", "Maybe", "No"])
    ts = edate + timedelta(days=random.randint(0, 3), hours=random.randint(9, 22), minutes=random.randint(0, 59))
    rows.append({
        "Timestamp": ts,
        "Which event did you attend?": ev,
        "Overall, how would you rate this event? (1 = Very Poor, 5 = Excellent)": overall,
        "How would you rate the ORGANIZATION of the event?": org,
        "How would you rate the CONTENT / activities?": content,
        "How would you rate the VENUE & facilities?": venue,
        "Your department": random.choice(depts),
        "Year of study": random.choice(years),
        "What did you like the most?": like,
        "What can we improve?": imp,
        "Would you attend a similar event again?": rec})
df = pd.DataFrame(rows)
tidy = df.copy(); tidy["Event_Type"] = tidy["Which event did you attend?"].map(lambda e: events[e][0])
tidy.columns = ["Timestamp", "Event", "Overall_Rating", "Organization_Rating", "Content_Rating", "Venue_Rating",
                "Department", "Year", "Liked_Most", "Improve", "Attend_Again", "Event_Type"]
tidy.to_csv("data/cleaned/event_feedback_tidy_reference.csv", index=False)

# ---- messy raw (Google Forms style) ----
raw = df.copy()
raw["Timestamp"] = raw.Timestamp.apply(lambda t: t.strftime(random.choice(["%m/%d/%Y %H:%M:%S", "%m/%d/%Y %H:%M:%S", "%Y-%m-%d %H:%M"])))
raw["Which event did you attend?"] = raw["Which event did you attend?"].apply(lambda e: random.choice([e, e, e, e.lower(), e.upper(), e + " "]))
raw["Your department"] = raw["Your department"].apply(lambda d: random.choice([d, d, d.lower(), " " + d]))
oc = "Overall, how would you rate this event? (1 = Very Poor, 5 = Excellent)"
raw[oc] = raw[oc].astype(object)
raw.loc[raw.sample(8, random_state=1).index, oc] = "5 stars"
raw.loc[raw.sample(4, random_state=2).index, oc] = 10        # out of range
raw.loc[raw.sample(10, random_state=3).index, oc] = None
for col in ["What did you like the most?", "What can we improve?"]:
    raw.loc[raw.sample(35, random_state=5).index, col] = None
raw.loc[raw.sample(12, random_state=6).index, "What can we improve?"] = random.choice(["NA", "n/a", "-"])
raw.loc[raw.sample(10, random_state=7).index, "What did you like the most?"] = "GREAT EVENT!!! 😍😍"
raw.loc[raw.sample(6, random_state=8).index, "What can we improve?"] = "Worst organization ever 😡"
raw = pd.concat([raw, raw.sample(15, random_state=9)]).sample(frac=1, random_state=4).reset_index(drop=True)
raw.to_csv("data/raw/event_feedback_raw.csv", index=False)
print("Done:", len(raw), "raw rows |", len(tidy), "tidy rows")
