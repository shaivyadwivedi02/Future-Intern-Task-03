# Key Concepts (plain English)

| Term | Meaning |
|---|---|
| **pandas DataFrame** | A table (like Excel) inside Python |
| **Data cleaning** | Fixing duplicates, typos, wrong types, and missing values before analysis |
| **Likert scale** | The 1–5 rating scale ("Very Poor" → "Excellent") |
| **Sentiment analysis** | Automatically judging whether text is positive, neutral, or negative |
| **VADER** | A rule-based sentiment tool built for short, informal text; gives a compound score −1 to +1 |
| **TextBlob** | Another simple sentiment library; gives polarity −1 to +1 |
| **Word cloud** | Picture where frequent words look bigger |
| **Theme tagging** | Grouping comments into topics (sound, timing, food…) using keywords |

## Why sentiment tools make mistakes
Try this in the notebook: the comment *"No complaints, great job"* can be labelled **Negative** because the word "complaints" sounds negative. Also watch for:
- **Sarcasm** ("Great, another 1-hour delay")
- **Suggestions** ("Maybe start on time") that are not really emotional
- **Rating vs comment mismatch** — 5 stars with a complaint often reveals a real issue

Always read a sample of comments yourself and mention this in your limitations.

## Ratings vs. sentiment
Ratings tell you *how much* people liked it; comments tell you *why*. Use both.
