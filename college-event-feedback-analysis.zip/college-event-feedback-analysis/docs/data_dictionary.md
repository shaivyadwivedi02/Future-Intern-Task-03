# Data Dictionary

Raw Google Forms column → short name used in the notebook

| Raw column | Short name | Description |
|---|---|---|
| Timestamp | Timestamp | When the form was submitted |
| Which event did you attend? | Event | TechFest 2025, AI & ML Workshop, Cultural Night, Hackathon 24hr, Career Guidance Seminar, Sports Day |
| Overall, how would you rate this event? (1–5) | Overall_Rating | 1 = Very Poor … 5 = Excellent |
| ORGANIZATION rating | Organization_Rating | 1–5 |
| CONTENT / activities rating | Content_Rating | 1–5 |
| VENUE & facilities rating | Venue_Rating | 1–5 |
| Your department | Department | CSE, ECE, Mechanical, Civil, MBA, IT |
| Year of study | Year | 1st–4th Year |
| What did you like the most? | Liked_Most | Free-text comment |
| What can we improve? | Improve | Free-text comment |
| Would you attend a similar event again? | Attend_Again | Yes / Maybe / No |

## Columns created in the notebook
| Column | Meaning |
|---|---|
| Comment | Liked_Most + Improve combined |
| Vader_Score | VADER compound score, −1 to +1 |
| Sentiment | Positive (≥ 0.05), Negative (≤ −0.05), else Neutral |
| TextBlob_Score | TextBlob polarity, −1 to +1 |
| Themes | Improvement topics found by keywords (e.g. Sound / AV) |
