# Use Your Own Google Form Data

1. Create a Google Form with: event name (dropdown), rating questions (Linear scale 1–5), and two short-answer questions (*What did you like most?* / *What can we improve?*).
2. Collect responses → in **Responses** tab click **Link to Sheets** → **File → Download → CSV**.
3. Put the CSV in `data/raw/` (or upload it in Colab).
4. In the notebook, update the `df.columns = [...]` line to match your columns **in order**.
5. Adjust the event-name fixes and the `themes` dictionary to your events and typical complaints.

⚠️ **Privacy:** remove names, emails and roll numbers before sharing data on GitHub. Only publish anonymized data.
